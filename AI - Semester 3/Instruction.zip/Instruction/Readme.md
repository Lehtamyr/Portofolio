# Deteksi Kecepatan Kendaraan - Aplikasi Streamlit

Proyek ini menunjukkan deteksi kecepatan kendaraan menggunakan aliran video langsung atau video rekaman. Sistem ini memproses video untuk memperkirakan kecepatan kendaraan secara real-time.

## Langkah 1: Persiapkan Folder

Buat folder baru dan salin file-file berikut ke dalamnya:
- `App.py`
- `requirements.txt`
- `yolov8x.pt`
- `sample1.mp4`

Anda dapat mengunduh file-file tersebut melalui link berikut:  
[Unduh File](https://drive.google.com/drive/folders/1V6-g42JIZZBOnP8USehgHdLvA4VN1ywX?usp=sharing)

## Langkah 2: Install Dependensi

Buka terminal dan pindah ke folder tempat file-file tersebut disalin. Misalnya:

```bash
cd foldernama
```
Kemudian, instal semua dependensi dengan menjalankan perintah berikut:
pip install -r requirements.txt

Pastikan Anda menggunakan versi library yang cukup baru agar program dapat berjalan dengan baik.

## Langkah 3: Jalankan Aplikasi
Untuk menjalankan aplikasi, gunakan perintah berikut di terminal:
streamlit run App.py

## Langkah 4: Akses Aplikasi
Jika aplikasi tidak terbuka secara otomatis, buka browser Anda dan akses alamat berikut:

localhost:8501

## Langkah 5: Pilih Kamera
Anda akan diminta untuk memilih salah satu opsi kamera yang tersedia. Berikut adalah daftar aliran kamera yang dapat dipilih:

[LIVE] Aliran Kamera:
Tol Dalam Kota (Kelapa Gading - Pulo Gebang)
URL: https://camera.jtd.co.id/camera/share/tios/2/78/index.m3u8

[LIVE] Jakarta - Bogor - Ciawi
URL: https://jmlive.jasamarga.com/hls/1/099ccdf/index.m3u8

[LIVE] Jakarta - Cikampek
URL: https://jmlive.jasamarga.com/hls/5/31668e25-dc03-4a1c-820c-4a35b1b0dc6c/index.m3u8

[LIVE] Jalan Layang MBZ Sheikh Mohamed Bin Zayed
URL: https://jmlive.jasamarga.com/hls/29/d7fe3a6/index.m3u8

[LIVE] Semarang Seksi A,B,C
URL: https://jmlive.jasamarga.com/hls/13/8bd946c/index.m3u8

[Pre-recorded] Video Contoh:
Sample Camera 1
Sumber: pexels.com

Catatan: Aliran kamera langsung [LIVE] terkadang mengalami masalah dalam pemuatan karena kondisi kamera (misalnya, kamera bisa saja offline).