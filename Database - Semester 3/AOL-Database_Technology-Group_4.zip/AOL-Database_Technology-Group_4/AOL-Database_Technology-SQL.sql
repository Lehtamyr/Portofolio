-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 19, 2024 at 04:40 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aol`
--

-- --------------------------------------------------------

--
-- Table structure for table `mscourier`
--

CREATE TABLE `mscourier` (
  `Courier_ID` char(4) NOT NULL CHECK (`Courier_ID` regexp '^C[0-9]{3}$'),
  `Courier_Name` varchar(64) NOT NULL,
  `Courier_Phone` varchar(15) NOT NULL CHECK (`Courier_Phone` regexp '^1-[0-9]{3}-[0-9]{3}-[0-9]{4}$')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mscourier`
--

INSERT INTO `mscourier` (`Courier_ID`, `Courier_Name`, `Courier_Phone`) VALUES
('C001', 'Danu Hertanu', '1-779-609-5374'),
('C002', 'Randy Ferdinand', '1-440-731-6303'),
('C003', 'Soetri Budiantoro', '1-331-514-0471'),
('C004', 'William Hantoro', '1-516-818-1116');

-- --------------------------------------------------------

--
-- Table structure for table `msdelivereditems`
--

CREATE TABLE `msdelivereditems` (
  `Delivery_ID` char(4) DEFAULT NULL,
  `Receiver_ID` char(4) DEFAULT NULL,
  `Item_ID` char(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msdelivereditems`
--

INSERT INTO `msdelivereditems` (`Delivery_ID`, `Receiver_ID`, `Item_ID`) VALUES
('D001', 'R001', 'I001'),
('D001', 'R004', 'I001'),
('D002', 'R002', 'I002'),
('D002', 'R002', 'I005'),
('D003', 'R002', 'I003'),
('D003', 'R005', 'I006'),
('D004', 'R003', 'I004');

-- --------------------------------------------------------

--
-- Table structure for table `msdeliveries`
--

CREATE TABLE `msdeliveries` (
  `Delivery_ID` char(4) NOT NULL CHECK (`Delivery_ID` regexp '^D[0-9]{3}$'),
  `Delivery_Date` date NOT NULL,
  `Sender_ID` char(4) DEFAULT NULL,
  `Courier_ID` char(4) DEFAULT NULL,
  `Delivery_Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msdeliveries`
--

INSERT INTO `msdeliveries` (`Delivery_ID`, `Delivery_Date`, `Sender_ID`, `Courier_ID`, `Delivery_Status`) VALUES
('D001', '2024-12-15', 'S001', 'C001', 'Shipped'),
('D002', '2024-12-15', 'S002', 'C002', 'Delivered'),
('D003', '2024-12-16', 'S003', 'C003', 'Shipped'),
('D004', '2024-12-16', 'S004', 'C004', 'In Progress');

-- --------------------------------------------------------

--
-- Table structure for table `msitem`
--

CREATE TABLE `msitem` (
  `Item_ID` char(4) NOT NULL CHECK (`Item_ID` regexp '^I[0-9]{3}$'),
  `Item_Name` varchar(64) NOT NULL,
  `Item_Weight` int(10) NOT NULL,
  `Shipping_Cost` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msitem`
--

INSERT INTO `msitem` (`Item_ID`, `Item_Name`, `Item_Weight`, `Shipping_Cost`) VALUES
('I001', 'Industrial Machine', 500, 200000),
('I002', 'Electric Generator', 300, 120000),
('I003', 'Otomotive Spare Parts', 750, 300000),
('I004', 'Heavy Equipment', 1000, 4000000),
('I005', 'Musical Instrument', 200, 80000),
('I006', 'Sport Apparel', 375, 150000);

-- --------------------------------------------------------

--
-- Table structure for table `msreceiver`
--

CREATE TABLE `msreceiver` (
  `Receiver_ID` char(4) NOT NULL CHECK (`Receiver_ID` regexp '^R[0-9]{3}$'),
  `Receiver_Name` varchar(64) NOT NULL,
  `Receiver_Address` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msreceiver`
--

INSERT INTO `msreceiver` (`Receiver_ID`, `Receiver_Name`, `Receiver_Address`) VALUES
('R001', 'Beta Store', 'Main St. 456'),
('R002', 'Omega Store', 'Anggrek St. 123'),
('R003', 'Alpha Store', 'Soekarno St. 205'),
('R004', 'Gamma Store', 'Sudirman St. 789'),
('R005', 'Jeep Store', 'Sudirman St. 001');

-- --------------------------------------------------------

--
-- Table structure for table `mssender`
--

CREATE TABLE `mssender` (
  `Sender_ID` char(4) NOT NULL CHECK (`Sender_ID` regexp '^S[0-9]{3}$'),
  `Sender_Name` varchar(64) NOT NULL,
  `Sender_Address` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mssender`
--

INSERT INTO `mssender` (`Sender_ID`, `Sender_Name`, `Sender_Address`) VALUES
('S001', 'PT Tori', 'Industrial St. 123'),
('S002', 'Berkah Store', 'Industrial St. 231'),
('S003', 'PT Wijaya Abadi', 'Mawar St. 321'),
('S004', 'Sukses Jaya', 'Mawar St. 123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mscourier`
--
ALTER TABLE `mscourier`
  ADD PRIMARY KEY (`Courier_ID`);

--
-- Indexes for table `msdeliveries`
--
ALTER TABLE `msdeliveries`
  ADD PRIMARY KEY (`Delivery_ID`);

--
-- Indexes for table `msitem`
--
ALTER TABLE `msitem`
  ADD PRIMARY KEY (`Item_ID`);

--
-- Indexes for table `msreceiver`
--
ALTER TABLE `msreceiver`
  ADD PRIMARY KEY (`Receiver_ID`);

--
-- Indexes for table `mssender`
--
ALTER TABLE `mssender`
  ADD PRIMARY KEY (`Sender_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
