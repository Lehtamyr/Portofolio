## Subtitle Downloader
This project (https://github.com/syedalisait/subtitle-downloader/) was refactored and improved by Bryan Valentino Wijaya, Cladio Bernard Octaviano, Kevin Jeremia, and Marco Bennedict Makin.

Subtitle Downloader is a Java Command Line tool to download subtitles for Movies in any language especially for Movies downloaded from Yify/YTS.

Download link: [subtitle-downloader](https://github.com/syedalisait/subtitle-downloader/releases/tag/v1.0)
